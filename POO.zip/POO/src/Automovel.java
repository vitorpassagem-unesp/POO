public class Automovel extends Veiculo{
    private Integer numeroAssentos;

    public Automovel(){}

    public Automovel(Integer numeroAssentos){
        this.setServico(servico);
    }

    public Automovel(String nome, Servico servico, Integer numeroAssentos){
        super(nome, servico);
        this.numeroAssentos = numeroAssentos;
    }

    public Integer getNumeroAssentos(){
        return numeroAssentos;
    }

    public void setNumeroAssentos(Integer numeroAssentos){
        this.numeroAssentos = numeroAssentos;
    }

}
