public class Caminhao extends Veiculo{
    public int neixos;
}
