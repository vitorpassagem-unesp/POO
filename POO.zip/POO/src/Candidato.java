public class Candidato {
    private String nome;
    private String partido;
    private int numeroVotos;
    private int numeroVotosEspeciais;

    public Candidato() {
    }

    public Candidato(String nome, String partido) {
        this.nome = nome;
        this.partido = partido;
    }
    public String getNome() {
        return nome;
    }
    public void setNome(String nome) {
        this.nome = nome;
    }
    public String getPartido() {
        return partido;
    }
    public void setPartido(String partido) {
        this.partido = partido;
    }
    public int getNumeroVotos() {
        return numeroVotos;
    }
    public void setNumeroVotos(int numeroVotos) {
        this.numeroVotos = numeroVotos;
    }
    public int getNumeroVotosEspeciais() {
        return numeroVotosEspeciais;
    }
    public void setNumeroVotosEspeciais(int numeroVotosEspeciais) {
        this.numeroVotosEspeciais = numeroVotosEspeciais;
    }

}
