import java.sql.Date;

public class Pessoa {
        private String nome;
        private int numeroFilhos;
        private int estadoCivil;
        private int trabalho;
        private double rendaBrutaMensal;
        private int voto;
        private Endereco endereco = new Endereco();
        private Date nascimento;

        public Pessoa(){
        }

        public Pessoa(String nome, Endereco endereco, int numeroFilhos, Date nascimento, int estadoCivil, int trabalho, double rendaBrutaMensal, int voto) {
            this.nome = nome;
            this.numeroFilhos = numeroFilhos;
            this.estadoCivil = estadoCivil;
            this.trabalho = trabalho;
            this.rendaBrutaMensal = rendaBrutaMensal;
            this.voto = voto;
            this.endereco = endereco;
            this.nascimento = nascimento;
        }
 
        public String getNome() {
            return nome;
        }
        public void setNome(String nome) {
            this.nome = nome;
        }
        public int getNumeroFilhos() {
            return numeroFilhos;
        }
        public void setNumeroFilhos(int numeroFilhos) {
            this.numeroFilhos = numeroFilhos;
        }
        public int getEstadoCivil() {
            return estadoCivil;
        }
        public void setEstadoCivil(int estadoCivil) {
            this.estadoCivil = estadoCivil;
        }
        public int getTrabalho() {
            return trabalho;
        }
        public void setTrabalho(int trabalho) {
            this.trabalho = trabalho;
        }
        public double getRendaBrutaMensal() {
            return rendaBrutaMensal;
        }
        public void setRendaBrutaMensal(double rendaBrutaMensal) {
            this.rendaBrutaMensal = rendaBrutaMensal;
        }
        public int getVoto() {
            return voto;
        }
        public void setVoto(int voto) {
            this.voto = voto;
        }
        public Endereco getEndereco() {
            return endereco;
        }
        public void setEndereco(Endereco endereco) {
            this.endereco = endereco;
        }
        public Date getNascimento() {
            return nascimento;
        }
        public void setNascimento(Date nascimento) {
            this.nascimento = nascimento;
        }

}
