import java.util.ArrayList;
import java.util.List;
import java.sql.Date;

public class EX02 {
    public static void main(String[] args) {
        Endereco end = new Endereco("Rua ABC", 123, "Bairro", "Cidade", 11300123, "SP");
        Date d = new Date(16/01/2004);
        Pessoa pessoa1 = new Pessoa("João", end, 3, d, 1, 1, 18000, 2);
        Pessoa pessoa2 = new Pessoa("Maria", end, 1, d, 1, 1, 1000, 1);
        Pessoa pessoa3 = new Pessoa("Pedro", end, 0, d, 1, 1, 1300, 2);
        Pessoa pessoa4 = new Pessoa("Ana", end, 3, d, 1, 1, 1500, 1);
        Pessoa pessoa5 = new Pessoa("Pedro", end, 0, d, 2, 3, 1800, 1);

        Candidato candidato1 = new Candidato("Fulano da Silva", "PSDB");
        Candidato candidato2 = new Candidato("Beltrano da Costa", "PT");
        Candidato candidato3 = new Candidato("Ciclano do Amaral", "MDB");
        Candidato nulo = new Candidato("Fulano da Silva", "n/a");
        Candidato branco = new Candidato("Branco","n/a");

        List<Pessoa> lista = new ArrayList<Pessoa>();
        lista.add(pessoa1);
        lista.add(pessoa2);
        lista.add(pessoa3);
        lista.add(pessoa4);
        lista.add(pessoa5);
        int numeroEleitores = 0, a = 0, b = 0, c = 0, e = 0, f = 0, g = 0, h = 0, j = 0;

        for (Pessoa p : lista){
            numeroEleitores++;
            if (p.getVoto()==1){
                a++;
                candidato1.setNumeroVotos(a);
            }
            else if (p.getVoto()==2){
                b++;
                candidato2.setNumeroVotos(b);
            }
            else if (p.getVoto()==3){
                c++;
                candidato3.setNumeroVotos(c);
            }
            else {
                e++;
                nulo.setNumeroVotos(e);
            }

            if (p.getVoto()==1 && p.getEstadoCivil()==1 && p.getNumeroFilhos()>=1 && p.getRendaBrutaMensal()<=1500){
                f++;
                candidato1.setNumeroVotosEspeciais(f);
            }
            else if (p.getVoto()==2 && p.getEstadoCivil()==1 && p.getNumeroFilhos()>=1 && p.getRendaBrutaMensal()<=1500){
                g++;
                candidato2.setNumeroVotosEspeciais(g);
            }
            else if (p.getVoto()==3 && p.getEstadoCivil()==1 && p.getNumeroFilhos()>=1 && p.getRendaBrutaMensal()<=1500){
                h++;
                candidato3.setNumeroVotosEspeciais(h);
            }
            else if (p.getVoto()==3 && p.getEstadoCivil()==1 && p.getNumeroFilhos()>=1 && p.getRendaBrutaMensal()<=1500){
                j++;
                branco.setNumeroVotosEspeciais(j);
            }

        }

        System.out.println("O numero total de eleitores é " + numeroEleitores);
        
        System.out.println("\nO numero total de pessoas que votaram no PT é " + candidato1.getNumeroVotos());
        System.out.println("O numero total de pessoas que votaram no PSDB é " + candidato2.getNumeroVotos());
        System.out.println("O numero total de pessoas que votaram no MDB é " + candidato3.getNumeroVotos());
        System.out.println("O numero total de pessoas que votaram nulo é " + nulo.getNumeroVotos());
        System.out.println("O numero total de pessoas que votaram branco é " + branco.getNumeroVotos());

        System.out.println("\nO numero de votos especiais do PT foi " + candidato1.getNumeroVotosEspeciais());
        System.out.println("O numero de votos especiais do PSDB foi " + candidato2.getNumeroVotosEspeciais());
        System.out.println("O numero de votos especiais do MDB foi " + candidato3.getNumeroVotosEspeciais());
        System.out.println("O numero de votos especiais nulo foi " + nulo.getNumeroVotosEspeciais());
        System.out.println("O numero de votos especiais em branco foi " + branco.getNumeroVotosEspeciais());



    }
}
